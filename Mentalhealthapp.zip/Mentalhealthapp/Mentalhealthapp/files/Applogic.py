import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import mutual_info_classif
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold
import warnings
from collections import Counter
import operator
warnings.filterwarnings('ignore')

class Applogic:

    def __init__(self):
        self.df = pd.read_csv("../statistics/cleaned_survey.csv") #fix relative to userpath
        self.encoder = LabelEncoder()
        self.dff= 0
        self.x = 0
        self.y = 0
        self.dtc = 0

    def trainmodel(self):
        #print("The labels are encoded as follows:")
        for col in self.df.columns:
            if col != 'Age':
                self.df[col] = self.encoder.fit_transform(self.df[col])
                #print({index : label for index, label in enumerate(self.encoder.classes_)})
        self.x=self.df.drop(columns=["treatment"])#x contains everythin except treatment
        self.y=self.df.drop(columns=[col for col in  self.df.columns if col != "treatment" ])#y contains treatment
        self.x=self.x.drop(["tech_company","self_employed","remote_work","mental_health_consequence","no_employees","supervisor"],axis=1)
        #print(self.y.treatment.value_counts()
        X_train,X_test,y_train,y_test = train_test_split(self.x,self.y,test_size=0.2)
        
        self.dtc = DecisionTreeClassifier(criterion = 'gini',
        max_depth= None,
        max_leaf_nodes=6,
        min_samples_leaf = 2,
        min_samples_split = 4,
        splitter ='random')
        self.dtc.fit(X_train, y_train)
        y_pred = self.dtc.predict(X_test)
        accuracy=accuracy_score(y_test,y_pred)
        return accuracy*100
        
    def graph_for_attributes(self):
        returnlist=[]
        treatment= self.y['treatment']
        Gender= self.x['Gender']
        family_history=self.x['family_history']
        work_interference=self.x['work_interfere']
        benefits=self.x['benefits']
        care_options=self.x['care_options']
        wellness_progam=self.x['wellness_program']
        seek_help=self.x['seek_help']
        anonymity=self.x['anonymity']
        leave=self.x['leave']
        phys_health_consequence=self.x['phys_health_consequence']
        coworkers=self.x['coworkers']
        mental_health_interview=self.x['mental_health_interview']
        phys_health_interview=self.x['phys_health_interview']
        mental_vs_physical=self.x['mental_vs_physical']
        obs_consequence=self.x['obs_consequence']
        fam_hist=0
        not_fam_hist=0
        work_int=0
        not_work_int=0
        ben=0
        not_ben=0
        care_o=0
        not_care_o=0
        welln=0
        notwelln=0
        shelp=0
        notshelp=0
        anonym=0
        notanonym=0
        Leave=0
        notleave=0
        phys_health_cons=0
        not_phys_health_cons=0
        cwork=0
        not_cwork=0
        mental_health_int=0
        not_mental_health_int=0
        phys_health_int=0
        not_phys_health_int=0
        mvsp=0
        notmvsp=0
        obs_con=0
        not_obs_con=0

        for (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o) in zip(treatment,family_history,work_interference,benefits,care_options,wellness_progam,seek_help,anonymity,leave,phys_health_consequence,coworkers,mental_health_interview,phys_health_interview,mental_vs_physical,obs_consequence):
            if a==1 and b==0:
                fam_hist=fam_hist+1
            elif a==0 and b==0:
                not_fam_hist=not_fam_hist+1
            elif a==1 and (c==2 or c==4):
                work_int=work_int+1
            elif a==0 and (c==2 or c==4):
                 not_work_int=not_work_int+1
            elif a==1 and d==1: 
                ben=ben+1
            elif a==0 and d==1:
                not_ben=not_ben+1
            elif a==1 and(e==0 or e==1):#changed
                care_o=care_o+1
            elif a==0 and(e==0 or e==1):#changed
                not_care_o=not_care_o+1
            elif a==1 and f==1:
                welln=welln+1
            elif a==0 and f==1:
                notwelln=notwelln+1
            elif a==1 and g==1:
                shelp=shelp+1
            elif a==0 and g==1:
                notshelp=notshelp+1
            elif a==1 and h==1:
                anonym=anonym+1
            elif a==0 and h==1:
                notanonym=notanonym+1
            elif a==1 and (i==1 or i==3):
                Leave=Leave+1
            elif a==0 and (i==1 or i==3):
                notleave=notleave+1
            elif a==1 and j==2:#changed
                phys_health_cons=phys_health_cons+1
            elif a==0 and j==2:
                not_phys_health_cons=not_phys_health_cons+1
            elif a==1 and k==0:
                cwork=cwork+1
            elif a==0 and k==0:
                not_cwork=not_cwork+1
            elif a==1 and l==1:
                mental_health_int=mental_health_int+1
            elif a==0 and l==1:
                not_mental_health_int=not_mental_health_int+1
            elif a==1 and m==1:
                phys_health_int=phys_health_int+1
            elif a==0 and m==1:
                not_phys_health_int=not_phys_health_int+1
            elif a==1 and n==1:
                mvsp=mvsp+1
            elif a==0 and n==1:
                notmvsp=notmvsp+1
            elif a==1 and o==1:
                obs_con=obs_con+1
            elif a==0 and o==1:
                not_obs_con=not_obs_con+1

    

        # print("Family history: "+ str(fam_hist))
        # print("\n")
        # print("no fam_hist: "+ str(not_fam_hist))
        # print("\n")
        # print("benefits: "+str(ben))
        # print("\n")
        # print("No benefits:"+ str(not_ben))
        # print("\n")
        # print("care options" +str(care_o))
        # print("\n")
        # print("not care options "+str(not_care_o))
        # print("\n")
        # print("Wellness "+str(welln))
        # print("\n")
        # print("not wellness "+str(notwelln))
        # print("\n")
        # print("seek help "+str(shelp))
        # print("\n")
        # print("not seek help "+str(notshelp))
        # print("\n")
        # print("anonym "+str(anonym))
        # print("\n")
        # print("not anonym "+str(notanonym))
        # print("\n")
        # print("leave "+str(Leave))
        # print("\n")
        # print("not leave "+str(notleave))
        # print("\n")
        # print("physical health consequences "+str(phys_health_cons))
        # print("\n")
        # print("not physical health consequences "+str(not_phys_health_cons))
        # print("\n")
        # print("coworkers "+str(cwork))
        # print("\n")
        # print("not coworkers "+str(not_cwork))
        # print("\n")
        # print("mental health interview "+str(mental_health_int))
        # print("\n")
        # print("not mental_health_interview "+str(not_mental_health_int))
        # print("\n")
        # print("physical health interview "+str(phys_health_int))
        # print("\n")
        # print("not physical health interview "+str(not_phys_health_int))
        # print("\n")
        # print("mental_vs_physical "+str(mvsp))
        # print("\n")
        # print("not mental_vs_physical "+str(notmvsp))
        # print("\n")
        # print("observed concequences "+str(obs_con))
        # print("\n")
        # print("not observed concequences "+str(not_obs_con))
        #templist={'family_history':fam_hist,'work interfere':work_int,'benefits':ben,'care_options':care_o,'wellness_program':welln,'Seek help':shelp,'anonymity':anonym,'Leave':Leave,'phys health consequence':phys_health_cons,'coworkers':cwork,'Mental health interview':mental_health_int,'Physical health_nterview':phys_health_int,'mental_vs_physical':mvsp,'Observed concequences':obs_consequence}
        #sortlist = dict(sorted(d.items(), key=operator.itemgetter(1),reverse=True))
        #new_sortlist=dict(itertools.islice(sortlist.items(), 0 ,3))
        #returnlist.append(new_sortlist)
        #for x in new_sortlist:
            #new_sortlist[x]=1-new_sortlist[x]

        #returnlist.append(new_sortlist)
        #returnlist.append({'family_history':fam_hist,'work interfere':work_int,'benefits':ben,'care_options':care_o,'wellness_program':welln,'Seek help':shelp,'anonymity':anonym,'Leave':Leave,'phys health consequence':phys_health_cons,'coworkers':cwork,'Mental health interview':mental_health_int,'Physical health_nterview':phys_health_int,'mental_vs_physical':mvsp,'Observed concequences':obs_consequence})




        returnlist.append([fam_hist,work_int,ben,care_o,welln,shelp,anonym,Leave,phys_health_cons,cwork,mental_health_int,phys_health_int,mvsp,obs_con])
        returnlist.append([not_fam_hist,not_work_int,not_ben,not_care_o,notwelln,notshelp,notanonym,notleave,not_phys_health_cons,not_cwork,not_mental_health_int,not_phys_health_int,notmvsp,not_obs_con])
        #print(returnlist)
        return returnlist


                
    def predictmodel(self,inputlist):
        self.dff = pd.DataFrame(columns=self.x.columns)
        self.dff.loc[0] = inputlist
        outcome = self.dtc.predict(self.dff)
        return outcome
    
    def send_df(self):
        return self.df

#app = Applogic()
#app.trainmodel()
#app.predictmodel()
