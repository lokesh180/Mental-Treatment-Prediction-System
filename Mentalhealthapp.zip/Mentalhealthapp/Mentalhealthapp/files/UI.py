
import PySimpleGUI as pysg  


class UI:

    def __init__(self):
        pass


    def Main_gui(self):
        returnlist = []   
        number=0
        finished =False
        pysg.theme('SandyBeach')
        Generalinfo=[[pysg.Text('Firstname',size=(20, 1), font='Lucida',key='_firstname_')],
        [pysg.Input(key='-INPUT1-', enable_events=True)],[pysg.Text('Lastname',size=(20, 1), font='Lucida',key='_lastname_')],
        [pysg.Input(key='-INPUT2-', enable_events=True)],
        [pysg.Text('Age ',size=(20, 1), font='Lucida',justification='left',key='_Age_')],
        [pysg.Input(key='-Age-', enable_events=True)],
        [pysg.Text('Gender ',size=(20, 1), font='Lucida',justification='left',key='_GENDER_')],
        [pysg.Combo(['Male','Female','Other'],key='_Gender_')],
        [pysg.Text('Country ',size=(20, 1), font='Lucida',justification='left',key='_Sort by_')],
        [pysg.Combo(['Sweden','India','Usa'],key='_countries_')]]
        
        healthcare=[[pysg.Text('Has your employer ever formally discussed mental health for example as part of a wellness campaign .',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Yes', "RADIO4",default=True,key='d1'),pysg.Radio('No', "RADIO4",key='d2'),pysg.Radio('I dont know', "RADIO4",key='d3')],
        [pysg.Text('Does your employer provide mental health benefits as part of health coverage. ',size=(50, 2), font='Lucida')],
        [pysg.Radio('Yes', "RADIO1",key='a1',enable_events=True),pysg.Radio('No', "RADIO1",key='a2',enable_events=True),pysg.Radio('I dont know', "RADIO1",default=True,key='a3',enable_events=True)],
        [pysg.Text('Do you know the options for mental health care available under your employer provided coverage  ',size=(50, 2), font='Lucida',justification='left',key='knowledge')],
        [pysg.Radio('Yes', "RADIO2",default=True,key='b1'),pysg.Radio('No', "RADIO2",key='b2'),pysg.Radio('I dont know', "RADIO2",key='b3')],
        [pysg.Text('Is your anonymity protected if you choose to take advantage of mental health or substance abuse treatment resources provided by your employer.',size=(60, 2), font='Lucida',justification='left',key='anonym')], 
        [pysg.Radio('Yes', "RADIO3",default=True,key='c1'),pysg.Radio('No', "RADIO3",key='c2'),pysg.Radio('I dont know', "RADIO3",key='c3')]]
        
        Treatment=[[pysg.Text('Does your employer provide resources to learn more about mental health issues and how to seek help?',size=(50, 2), font='Lucida')],
        [pysg.Radio('Yes', "RADIO5",default=True,key='e1'),pysg.Radio('No', "RADIO5",key='e2'),pysg.Radio("I don't know", "RADIO5",key='e3')],
        [pysg.Text('If a mental health issue prompted you to request a medical leave from work, asking for that leave would be?',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Very easy', "RADIO6",default=True,key='f1'),pysg.Radio('Somewhat easy', "RADIO6",default=True,key='f2'),pysg.Radio('Very difficult', "RADIO6",key='f3'),pysg.Radio('Somewhat difficult', "RADIO6",key='f4'),pysg.Radio("Don't know", "RADIO6",key='f5')]]
        
        opendness_for_disscussion=[[pysg.Text('Do you think that discussing a physical health issue with your employer would have negative consequences?',size=(50, 2), font='Lucida')],
        [pysg.Radio('Yes', "RADIO7",default=True,key='g1'),pysg.Radio('No', "RADIO7",key='g2'),pysg.Radio('I dont know', "RADIO7",key='g3')],
        [pysg.Text('Would you feel comfortable dissucssing a mental health dissorder with your coworkers? ',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Yes', "RADIO8",default=True,key='h1'),pysg.Radio('No', "RADIO8",key='h2'),pysg.Radio('Some of them', "RADIO8",key='h3')],
        [pysg.Text('Would you bring up a mental health issue with a potential employer in an interview?',size=(60, 2), font='Lucida',justification='left')], 
        [pysg.Radio('Yes', "RADIO9",default=True,key='i1'),pysg.Radio('No', "RADIO9",key='i2'),pysg.Radio('Maybe', "RADIO9",key='i3')],
        [pysg.Text('Would you be willing to bring up a physical health issue with a potential employer in an interview?',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Yes', "RADIO10",default=True,key='j1'),pysg.Radio('No', "RADIO10",key='j2'),pysg.Radio('Maybe', "RADIO10",key='j3')],
        [pysg.Text('Have you heard of or observed negative concequences for co-workers who have been opened about mental health issues in your workplace?',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Yes', "RADIO11",default=True,key='k1'),pysg.Radio('No', "RADIO11",key='k2')]]

        other=[[pysg.Text('Do you have a family history of mental illness?',size=(100, 1), font='Lucida')],
        [pysg.Radio('Yes', "RADIO12",default=True,key='l1'),pysg.Radio('No', "RADIO12")],
        [pysg.Text('If you have a mental health issue do you feel that it interferes with your work when not being treated effectively. ',size=(50, 2), font='Lucida',justification='left')],
        [pysg.Radio('Often', "RADIO13",default=True,key='m1'),pysg.Radio('Rarely', "RADIO13",key='m2'),pysg.Radio('Never', "RADIO13",key='m3'),pysg.Radio('Sometimes', "RADIO13",key='m4'),pysg.Radio("Don't know", "RADIO13",key='m5')],
        [pysg.Text('Do you feel that your employer takes mental health as seriously as physical health? ',size=(70, 1), font='Lucida',justification='left')], 
        [pysg.Radio('Yes', "RADIO14",default=True,key='n1'),pysg.Radio('No', "RADIO14",key='n2'),pysg.Radio('I dont know', "RADIO14",key='n3')]]
        
        layout = [[pysg.TabGroup([[pysg.Tab('General info', Generalinfo)],[pysg.Tab('Health care availability', healthcare)],[pysg.Tab('Treatment', Treatment)],[pysg.Tab('Discussion', opendness_for_disscussion)],[pysg.Tab('Other', other)]])],
                  [[pysg.Text('Do you accept that the answers you have provided will be used stored for further research within the area of mental health issues in techology workplaces?:',size=(70, 2), font='Lucida',justification='left',key='_Remote_')],
        [pysg.Radio('Yes', "RADIO15",key='_stored_',default=True),pysg.Radio('No', "RADIO15")],
        pysg.Button('Submit', font=('Times New Roman',12),key='_OK_')]]
        window = pysg.Window('MTPS(A decision support system for mental health issue prediction)', layout)
        while not finished:
            ev,val = window.read()
            if ev in (pysg.WIN_CLOSED,''):
                exit(0)

            if ev == '_OK_':
                Firstname=val['-INPUT1-']
                returnlist.append(Firstname)
                lastname=val['-INPUT2-']
                returnlist.append(lastname)
                Country=val['_countries_']
                returnlist.append(Country)
                Age=val['-Age-']
                returnlist.append(Age)
                Gender=val['_Gender_']
                if Gender == "Female":
                    returnlist.append(0)
                elif Gender == "Male":
                    returnlist.append(1)
                else:
                    returnlist.append(2)
                
                if val['l1']==True:
                    print("true")
                    family_history = 0

                else:
                    family_history = 1
                    print("false")
                returnlist.append(family_history)

                if val['m1']==True:
                    work_interference=2
                elif val['m2']==True:
                    work_interference=3
                elif val['m3']==True:
                    work_interference=1
                elif val['m4']==True:
                    work_interference=4
                elif val['m5']==True:
                    work_interference=0
                returnlist.append(work_interference)

                if val['a1']==True:
                    Benefits=2
                elif val['a2']==True:
                    Benefits=1
                elif val['a3']==True:
                    Benefits=0
                returnlist.append(Benefits)

                if val['b1']==True:
                    Care_options=2
                elif val['b2']==True:
                    Care_options=0
                else:
                    Care_options=1
                returnlist.append(Care_options)

                if val['d1']==True:
                    wellness_program=2
                elif val['d2']==True:
                    wellness_program=1
                elif val['d3']==True:
                    wellness_program=0
                returnlist.append(wellness_program)

                if val['e1']==True:
                    seek_help=2
                elif val['e2']==True:
                    seek_help=1
                else:
                    seek_help=0
                returnlist.append(seek_help)

                if val['c1']==True:
                    Anonymity=2
                elif val['c2']==True:
                    Anonymity=1
                elif val['c3']==True:
                    Anonymity=0
                returnlist.append(Anonymity)

                if val['f1']==True:
                    leave=4
                elif val['f2']==True:
                     leave=2
                elif val['f3']==True:
                     leave=3
                elif val['f4']==True:
                     leave=1
                elif val['f5']==True:
                     leave=0
                returnlist.append(leave)

                if val['g1']==True:
                    phys_health=2
                elif val['g2']==True:
                    phys_health=1
                elif val['g3']==True:
                    phys_health=0
                returnlist.append(phys_health)

                if val['h1']==True:
                    coworkers=2
                elif val['h2']==True:
                    coworkers=0
                elif val['h3']==True:
                    coworkers=1
                returnlist.append(coworkers)

                if val['i1']==True:
                    mental_health_interview=2
                elif val['i2']==True:
                    mental_health_interview=1
                elif val['i3']==True:
                    mental_health_interview=0
                returnlist.append(mental_health_interview)

                if val['j1']==True:
                    phys_health_interview=2
                elif val['j2']==True:
                    phys_health_interview=1
                elif val['j3']==True:
                    phys_health_interview=0
                returnlist.append(phys_health_interview)

                if val['n1']==True:
                    mentalvsphysical=2
                elif val['n2']==True:
                    mentalvsphysical=1
                elif val['n3']==True:
                    mentalvsphysical=0
                returnlist.append(mentalvsphysical)

                if val['k1']==True:
                    obs_consequence=1

                else:
                    obs_consequence=0
                if val['_stored_']==True:
                    stored_info='yes'
                returnlist.append(obs_consequence)

                window.close()
                finished=True
        return returnlist
                
#ui = UI()
#lis = ui.Main_gui()
#ui.submission_gui(lis)

   