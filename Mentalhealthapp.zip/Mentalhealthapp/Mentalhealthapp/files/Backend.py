import pymysql
class Backend:

    def __init__(self):
        self.connection = pymysql.connect(host='localhost',
                             user='root',
                             password='lokesh180',
                             db='DSS')
        print("Table created")
        pass

        self.cursor = self.connection.cursor()

    def create_table(self):
        self.cursor.execute("create table survey (Age int, Gender varchar(255), family_history varchar(255), work_interfere varchar(255), benefits varchar(255), care_options varchar(255), wellness_program varchar(255), seek_help varchar(255), anonymity varchar(255), leave varchar(255), phys_health_consequence varchar(255), coworkers varchar(255), mental_health_interview varchar(255), phys_health_interview varchar(255), mental_vs_physical varchar(255), obs_consequence varchar(255))")
        self.connection.commit()
    def insert(self):
        self.cursor.execute("INSERT INTO symptom values ('Kabir','New Delhi')")
        self.connection.commit()

    def loadfromdb(self):
        # Create a new query that selects the entire contents of `employee`
        sql = "SELECT * FROM `symptom`"
        self.cursor.execute(sql)

        # Fetch all the records and use a for loop to print them one line at a time
        result = self.cursor.fetchall()
        for i in result:
            print(i)

    def close(self):
        self.connection.close()


#b = Backend()
#b.create_table()
#b.insert()
#b.loadfromdb()
#b.close()