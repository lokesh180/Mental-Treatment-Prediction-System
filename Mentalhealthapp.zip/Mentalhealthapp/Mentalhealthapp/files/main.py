import sys
import os
from UI import UI
from Applogic import Applogic
from Backend import Backend
#import mysql.connector
from fpdf import FPDF
import matplotlib.pyplot as pyplt
import numpy as nump
import threading
import PySimpleGUI as pysg
import datetime
#import cv2
from PIL import Image
from random import randint
interrupt=0
ui=UI()
app =Applogic()
#def commandhandler():
 #   b=Backend()
  #  if sys.argv[1]=="clear":
   #     b.clear()
   # elif len(sys.argv)>=3:
   #     cmd=sys.argv[1]
    #    file=sys.argv[2]
    #    if cmd=='insecdrt' and file.endswith('.csv'):
    #        b.insert(file)


def create_graph(graphdata):
    for (x,y,z) in zip(graphdata[0].values(),graphdata[1].values(),graphdata[0].keys()):
        haslist.append(x)
        hasnotlist.append(y)
        ticks.append(z)
    figure = pyplt.subplots(figsize =(12, 8))
    bar1 = nump.arange(len(haslist))
    bar2 = [x + 0.25 for x in bar1]
    pyplt.bar(bar1,haslist, color ='r', width = 0.25,edgecolor ='grey', label ='Mental health issues')
    pyplt.bar(bar2, hasnotlist, color ='b', width = 0.25,edgecolor ='grey', label ='Not mental health issues')
    pyplt.xticks([r + 0.25 for r in range(len(haslist))],ticks)
    pyplt.legend()
    pyplt.savefig('../pictures/graph.png')
    #returnlist.append([fam_hist,work_int,ben,care_o,welln,shelp,anonym,leave,phys_health_cons,cwork,mental_health_int,phys_health_int,mvsp,obs_con])
    #returnlist.append([not_fam_hist,not_work_int,not_ben,not_care_o,notwelln,notshelp,notanonym,notleave,not_phys_health_cons,not_cwork,not_mental_health_int,not_phys_health_int,notmvsp,not_obs_con])

def treatment(inputlist):
    treatmentlist = []
    family_history=inputlist[2]
    work_interference=inputlist[3]
    Benefits=inputlist[4]
    Care_options=inputlist[5]
    wellness_program=inputlist[6]
    seek_help=inputlist[7]
    Anonymity=inputlist[8]
    leave=inputlist[9]
    phys_health=inputlist[10]
    coworkers=inputlist[11]
    mental_health_interview=inputlist[12]
    phys_health_interview=inputlist[13]
    mentalvsphysical=inputlist[14]
    obs_consequence=inputlist[15]

    if wellness_program==0 or wellness_program==1 or Care_options==1 or Care_options==0 or seek_help==0 or Benefits==0 or mentalvsphysical==0:
        treatmentlist.append({'Suggestion':'Conctact your supervisor/employer for more information regarding available resources for improving mental health.'})

    if Benefits==1 or obs_consequence==1 or mentalvsphysical==1:
        treatmentlist.append({'Suggestion':'Contact the safety representative at your workplace for more information on how to aquire resources for improving mental health.'})
        treatmentlist.append({'Suggestion':'Join a trade union if you havent done so already and disscuss the situation','Link':'https://www.xn--fackfrbund-icb.com/fackforbund'})

    if Anonymity==0 or Anonymity==1:
        treatmentlist.append({'Suggestion':'If your issues are alcohol related contact Alkoholhjälpen for information,support and help regarding your alcohol consumption','Link':'https://alkoholhjalpen.se/'})
        treatmentlist.append({'Suggestion':'If your issues are related to drug use contact Droghjälpen for information,support and help regarding your drug use','Link':'https://droghjalpen.se/'})

    if leave==0:
        treatmentlist.append({'Suggestion':'Contact your supervisor/employer for more information regarding the ability to take a medical leave.'})
   
    if leave == 3 or leave==1:
        treatmentlist.append({'Suggestion':'Contact Arbetsmiljöverket and check if you have legal rights to take out medical leave','Link':'https://www.av.se/om-oss/kontakta-oss/'})

    if phys_health == 2 or phys_health==0 or coworkers==2 or mental_health_interview==2 or phys_health_interview==2 or seek_help==1:
        treatmentlist.append({'Suggestion':'If you for any reason feel uncomfortable about being open about health issues or you just want to learn more about available help that exists 1177 Vårdguiden provides you with various information about mental health treament such as KBT,psychotherapy,psychoatric therapy etc as well as contact information to patient and related parties ','Link':'https://www.1177.se/liv--halsa/psykisk-halsa/att-soka-stod-och-hjalp/kbt-pa-natet/'}) 
    
    if family_history==0 or work_interference==1 or work_interference==4 or work_interference==0:
        treatmentlist.append({'Suggestion':'KBT is an effective treatment for stress,sleep deprevation,depression and anxiety among others','Link':'https://www.1177.se/liv--halsa/psykisk-halsa/att-soka-stod-och-hjalp/kbt-pa-natet/'})

    return treatmentlist

def cause(inputlist):
    list_of_causes = {}
    family_history=inputlist[2]
    work_interference=inputlist[3]
    Benefits=inputlist[4]
    Care_options=inputlist[5]
    wellness_program=inputlist[6]
    seek_help=inputlist[7]
    Anonymity=inputlist[8]
    leave=inputlist[9]
    phys_health=inputlist[10]
    coworkers=inputlist[11]
    mental_health_interview=inputlist[12]
    phys_health_interview=inputlist[13]
    mentalvsphysical=inputlist[14]
    obs_consequence=inputlist[15]
    if work_interference==2 or work_interference==4 or work_interference==0:
        list_of_causes['work_interference']='You may feel that your current mental health issue interferes with your work'
    if phys_health==2 or phys_health==0 or obs_consequence==1:
        list_of_causes['Fear of repurcussion']='You may be concerned that being open about health issues will lead to negative concequences.'
    if coworkers==0 or mental_health_interview==1 or phys_health_interview==1:
        list_of_causes['Lack of opendness']='You may be uncomfortable with being open about health issues '
    if mentalvsphysical==1 or mentalvsphysical==0 :
        list_of_causes['Attitude towards mental health']='Your employer may have a certain skepticism towards mental health issues'
    if Benefits==1 or Benefits==0 or Care_options==0 or wellness_program==1 or wellness_program==0 or seek_help==1 or seek_help==0 or leave==3 or leave==1 or leave==0:
        list_of_causes['Employer provided benefits']='Your employer may not be providing you with sufficient help for your Mental health'
    if Anonymity==1 or Anonymity==0:
        list_of_causes['Anonymity']='You may be concerned about your anonymity if choosing to take advantage of mental health or substance abuse treatment resources that is being provided '
    if family_history==0:
        list_of_causes['family_history']='You have a family history of mental illness.'
    
    return list_of_causes

def generatepdf(userinput,likelihood):
    global app
    accuracy=round(app.trainmodel())
    results="According to the results recieved from you it appears that it is a " +likelihood+ "\nlikelihood that you will you will be developing mental health issues in\nyour current workplace with an estimated accuracy of "+str(accuracy)+"%"
    global interrupt
    date = datetime.date.today()
    file = FPDF()
    file.add_page()
    file.image("../pictures/1.png",0,0,210)
    file.set_font('Arial', size = 15)
    file.cell(162, 1, txt = str(date),ln = 0, align = 'R')
    file.add_page()
    file.image("../pictures/2.png",0,0,210)

    #graphdata=app.graph_for_attributes()
    #create_graph(graphdata)
    file.add_page()
    file.image("../pictures/3.png",0,0,210)
    file.multi_cell(0,40,"\n",align = 'L')
    file.multi_cell(0,5,results,align = 'L')
    if likelihood == 'high':
        file.add_page()
        file.image("../pictures/4.png",0,0,210)
        file.multi_cell(0,40,"\n",align = 'L')
        file.multi_cell(0,5,"We identified the following attributes that may cause you to develop mental health issues",align = 'L')
        file.multi_cell(0,10,"\n",align = 'L')
        list_of_causes=cause(userinput)
        index=0
        for key,value in list_of_causes.items():
            index+=1
            result=str(index)+': '+value
            file.multi_cell(0,5,result,value,align = 'L')
            file.multi_cell(0,5,"\n",align = 'L')
        
        file.add_page()
        file.image("../pictures/5.png",0,0,210)
        file.multi_cell(0,40,"\n",align = 'L')
        file.multi_cell(0,5,"We belive that the following website/websites will provide you the appropriate guidance",align = 'L')
        file.multi_cell(0,10,"\n",align = 'L')
        treatmentlist=treatment(userinput)
        index=0
        for Dict in treatmentlist:
            file.multi_cell(0,5,"\n",align = 'L')
            for key,value in Dict.items():
                file.multi_cell(0,5,value,align = 'L')
                

    file.output("../results/results.pdf")
    interrupt=1

def predict(app, inputlist):
    
    outcome = app.predictmodel(inputlist)
    if outcome[0] == 1:
        likelihood='high'
    else:
        likelihood='low'
    generatepdf(inputlist,likelihood)


def main():
    global interrupt
    global ui
    global app
    modelaccuracy=app.trainmodel()
    inputlist=ui.Main_gui()
    #print(inputlist)
    #inputlist = ['Lokesh', 'Kola', 'Sweden', '22', 1, 1, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1]
    inputlist[3] =int(inputlist[3])
    inputlist = inputlist[3:]
    pysg.theme('SandyBeach')
    layout = [[pysg.Text('', size=(25, 1), font=('Courier', 15),key='update')]]
    win = pysg.Window('Exporting to pdf', layout)
    loading = win['update']
    state = 0
    t1 = threading.Thread(target = predict,args=(app,inputlist))
    t1.start()
    while interrupt == 0:
        ev, val = win.read(timeout=100)
        if ev == pysg.WINDOW_CLOSED:
            break
        state = (state+1)%25
        loading.update('█'*state)
        #pysg.PopupAnimated(pysg.DEFAULT_BASE64_LOADING_GIF, background_color='white', time_between_frames=100)
    t1.join()
    win.close()
    #Image.close('../pictures/exitscreen.png')

    



   # if len(sys.argv)>2:
   # commandhandler()
   # window=None
   # finished=False
   # while not finished:  
   #     finished=True
        #finished=ui.submission_gui(inputlist)
    
       
    

if __name__=="__main__":
    main()