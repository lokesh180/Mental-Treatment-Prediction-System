from random import randint
import PySimpleGUI as pysg

pysg.theme('SandyBeach')

layout = [[pysg.Text('',font=('Courier', 15),key='update')]]
win = pysg.Window('Exporting to pdf', layout)
loading = win['update']
state = 0
while True:

    ev, val = win.read(timeout=100)

    if ev == pysg.WINDOW_CLOSED:
        break
    state = (state+1)%25
    loading.update('█'*state)

win.close()
