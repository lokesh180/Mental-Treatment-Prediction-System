import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import mutual_info_classif
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import StratifiedKFold
import warnings
warnings.filterwarnings('ignore')
df = pd.read_csv("/Users/lokeshkola/Desktop/cleaned_survey.csv")
encoder = LabelEncoder()
print("The labels are encoded as follows:")
for col in df.columns:
    if col != 'Age':
        df[col] = encoder.fit_transform(df[col])
        print({index : label for index, label in enumerate(encoder.classes_)})

x=df.drop(columns=["treatment"])
y=df.drop(columns=[col for col in  df.columns if col != "treatment" ])
x=x.drop(["tech_company","self_employed","remote_work","mental_health_consequence","no_employees","supervisor"],axis=1)
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size=0.2)
dtc = DecisionTreeClassifier(criterion = 'gini',
 max_depth= None,
 max_leaf_nodes=6,
 min_samples_leaf = 2,
 min_samples_split = 4,
 splitter ='random')
dtc.fit(X_train, y_train)
y_pred = dtc.predict(X_test)
accuracy=accuracy_score(y_test,y_pred)
print(accuracy*100)
dff = pd.DataFrame(columns=x.columns)
dff.loc[0] = [1,0,1,0,1,1,0,1,1,0,0,0,1,0,1,0]
a = dtc.predict(dff)
print(a)