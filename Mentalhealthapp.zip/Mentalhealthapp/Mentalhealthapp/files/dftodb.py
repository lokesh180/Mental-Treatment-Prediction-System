from sqlalchemy import create_engine
import Applogic
engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}"
                       .format(user="root",
                               pw="lokesh180",
                               db="DSS"))
a = Applogic.Applogic()
dataframe = a.send_df()
dataframe.to_sql('survey', con = engine, if_exists = 'append', chunksize = 1000)